<?php
   //include_once("student.html");
  include_once("navigation.php");
  echo "";
?><html>
<head>
<br>
</head>
<body>
  <br>
<div align="center">
			<fieldset>
            <legend>Results</legend>
<body>
    <?php
 
include_once 'Crud.php';

$crud = new Crud();

$query = "Select * from routine where id='32456'";

$result = $crud->getData($query);

?>
        
<center><table border="1" class="table">


<b><tr>
<td>Course</td>
<td>Section</td>
<td>Teacher</td>
<td>Midterm</td>
<td>FinalTerm</td>
</tr>
</b>

  <?php
   foreach($result as $key=>$res){
     echo "<tr>";
     echo "<td>".$res['Sectinon']."</td>";
     echo "<td>".$res['Course']."</td>";
     echo "<td>".$res['Teacher']."</td>";
     echo "<td>".$res['MidTerm']."</td>";
     echo "<td>".$res['FinalTerm']."</td>";

     echo "</tr>";
   }
   ?>
    	
</fieldset>
</form>
</div>
</div>
</div>

<div align="center">
<br>
</div>
</div>
	</body>
	</html>

