<!DOCTYPE html>
<html>
<head>
  <title>XCOMPANY LOGIN FORM</title>
</head>
<body>
  <table border="1">
    <tr>
  <img src="xcompany.png" alt="Xcompany" width="200" height="S100">
</tr>
<div class="navbar">
      <ul>
        <li><a href="home.html">HOME</a></li>
        <li><a href="registration.html">Registration</a></li>
        
        <li style="float: left"><a href="login.html">LOGIN</a></li>
      </ul>
      <hl>
    </div>
<div class="flex-wrap">
    <fieldset>
        <form action novalidate>
               
            <br>
            <label for="reset">Reset</label> 
            </br> 

            <input class="sign-up sign-in reset" type="email" placeholder="Email" />
            <input class="sign-up sign-in" type="password" placeholder ="Password" />
            <input class="sign-up" type="password" placeholder ="Repeat Password" />
            <button><a href="login.html">Submit</button>        
            
        </form>
    </fieldset>
</div>
</head>
</html>