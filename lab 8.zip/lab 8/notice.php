<!DOCTYPE html>
<html>
<head>
    <title>
        Notice
    </title>
</head>
<body>

    <body style="background-color:powderblue;"></body>
<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
    <br><br>
                    <a href="home1.html">HOME</a></li>
                    <a href="login.html">Login</a>
                    <a href="registration.html">Registration</a>
                    <br><br>
                <header class="row_header">
                    <h2><span>Notices</span></h2>
                </header>
                    <div id="notice">
                            <div class="bs-callout">
                                <div class="date">
                                   <p> 16-Nov-2020</p>
                                </div>
                                <a>Dr. Anwarul Abedin Lecture Series with Mr. Mohibul Hassan Chowdhoury, posted a meeting today at 11.00 AM</a>
                            </div>
                                 2020<br>
                                 <p> 20-Nov-2020</p>
                                <a href="/scholarship-waiver-discount">ADJUSTMENT OF SCHOLARSHIP/ WAIVER/ DISCOUNT</a>
                    </div>
                            

                <div class="pad-bt-20">
                   
                    
                </div>
            </div>




</body>
</html>