<!DOCTYPE html>
<html>
<html>
<head>
  <title> HOME </title>
</head>
<body>
  <body style="background-color:powderblue;"></body>


<center>
   </table>
  <div id="container">
        <h1 style="font-size:30px;text-align: center;">
        
       <p class="line-1 anim-typewriter">Welcome to AIUB School</p>
     </h1>
    <div class="navbar">
      <ul>
        <h2 style="font-size:20px;text-align: center;">
        <li><a href="home.php">HOME</a></li>
        <li><a href="registration.php">Registration</a></li>
        <li><a href="notice.php">Notice</li>
          <li><a href="Admin.php">Admin Portal</li>
            <li><a href="Teacherregistration.php">Teacher Registration</li>
            

        <li style="float: center"><a href="student.php">LOGIN</a></li>
      
        </li>
      </ul>
    </h2>
    </div>
</body>
</html>
